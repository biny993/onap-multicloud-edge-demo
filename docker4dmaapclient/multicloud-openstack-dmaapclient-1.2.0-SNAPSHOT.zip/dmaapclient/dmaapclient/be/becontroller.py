# Copyright (c) 2017-2018 Wind River Systems, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import traceback
import json

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from django.conf import settings
from common.msapi import extsys
from dmaapclient.be.tasks import dmaaplistner

from django.core.cache import cache

logger = logging.getLogger(__name__)

class DmaapClientCtrl(APIView):
    '''
    control plane of DMaaPClient

    '''

    def __init__(self):
        self._logger = logger
        self.proxy_prefix = settings.PLUGIN_PREFIX


    def get(self, request):
        '''
        get blob of dmaapclient-config
        :param request:
        :return:
        '''
        self._logger.debug("with META: %s" % request.META)
        try:
            dmaapclient = cache.get("dmaapclient_config")
            pass
        except Exception as e:
            self._logger.error("exception:%s" % str(e))
            return Response(data={'error': str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        self._logger.info("return with %s" % status.HTTP_200_OK)
        return Response(data={"dmaapclient_config":dmaapclient},
                        status=status.HTTP_200_OK)


    def post(self, request):
        '''
        update the blob of dmaapclient-config
        :param request:
        :return:
        '''
        self._logger.debug("with META: %s, with data: %s" % (request.META, request.data))
        try:
            if request.data and request.data.get("dmaapclient_config", None):
                dmaapclient_config = request.data.get("dmaapclient_config", None)
                cache.set("dmaapclient_config",dmaapclient_config, None)

                # notify task
                dmaaplistner.delay()

        except Exception as e:
            self._logger.error("exception:%s" % str(e))
            return Response(data={'error': str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        self._logger.info("return with %s" % status.HTTP_201_CREATED)
        return Response(data=cache.get("dmaapclient_config"),
                        status=status.HTTP_201_CREATED)

    def delete(self, request):
        '''
        delete the blob of vesagent-config, remove it from backlog and stop the vesagent worker if no backlog
        :param request:
        :return:
        '''
        self._logger.debug("with META: %s" % request.META)
        try:
            cache.set("dmaapclient_config", None, None)
        except Exception as e:
            self._logger.error("exception:%s" % str(e))
            return Response(data={'error': str(e)},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        self._logger.info("return with %s" % status.HTTP_200_OK)
        return Response(status=status.HTTP_200_OK)


