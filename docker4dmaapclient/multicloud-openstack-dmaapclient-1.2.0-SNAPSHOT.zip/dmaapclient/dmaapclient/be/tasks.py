# Copyright (c) 2017-2018 Wind River Systems, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

### VES agent workers
from __future__ import absolute_import, unicode_literals
from dmaapclient.celery import app
import os
import logging
import json
import time
import urllib2
import re

from django.core.cache import cache

from common.utils import restcall
from common.msapi import extsys

logger = logging.getLogger(__name__)


@app.task(bind=True)
def dmaaplistner(self):
    # make sure only one task runs here

    logger.debug("dmaaplistner starts")

    # sleep for next_time_slot
    success = True
    while success:

        try:
            dmaapclient_config = cache.get("dmaapclient_config")

            if not dmaapclient_config:
                break

            logger.debug("dmaapclient_config: %s" % (dmaapclient_config))

            success = processDmaapMessage(dmaapclient_config)
            if not success:
                break
            time.sleep(1)

        except Exception as e:
            logger.error("exception:%s" % str(e))

    logger.debug("dmaaplistner stops")


def processDmaapMessage(dmaapclient_config):

    try:
        #decode dmaapclient_config

        #dmaap_endpoint = dmaapclient_config.get("endpoint",None)
        #topic = dmaapclient_config.get("topic",None)
        #dmaapsub_url = dmaap_endpoint + "/events/" + topic + "/multicloud-event-listener/1?timeout=6000&limit=10&filter="
        dmaapsub_url = dmaapclient_config.get("topic_subscribe_url", None)
        headers = {'Content-Type': 'application/json'}

        if not dmaapsub_url:
            logger.error("invalid topic_subscribe_url %s" % dmaapsub_url)
            return False

        request = urllib2.Request(url=dmaapsub_url, headers=headers)
        time.sleep(1)
        response = urllib2.urlopen(request)

        # dump the response
        resp = response.read()
        # logger.debug("dmaap response is: %s" % resp)

        events = json.loads(resp) if resp else []
        for event in events:
            logger.debug("dmaap event is: %s" % event)
            handleDmaapEvent(dmaapsub_url, json.loads(event))

        return True

    except Exception as e:
        logger.error("exception:%s" % str(e))

    return False

'''
For ONS EU DEMO ONLY: This is the hacking of APPC restart message triggered by:
    Fault_MultiCloud_VMFailure
        -> Holmes ControlLoop-vCPE-48f0c2c3-a172-4192-9ae3-052274181b6e
            -> Policy ControlLoop-vCPE-48f0c2c3-a172-4192-9ae3-052274181b6e rules
                -> APPC LCM event: restart

handle following event only:  restart the vm with vserver name specified by vnf-id
{
	"body": {
		"input": {
			"common-header": {
				"timestamp": "2018-09-12T09:15:40.334Z",
				"api-ver": "2.00",
				"originator-id": "7b3a8a9c-1d5a-4ed2-8106-3a9e490846a3",
				"request-id": "7b3a8a9c-1d5a-4ed2-8106-3a9e490846a3",
				"sub-request-id": "1",
				"flags": {}
			},
			"action": "Restart",
			"action-identifiers": {
				"vnf-id": "zdfw1lb01dns01"
			}
		}
	},
	"version": "2.0",
	"rpc-name": "restart",
	"correlation-id": "7b3a8a9c-1d5a-4ed2-8106-3a9e490846a3-1",
	"type": "request"
}

'''
def handleDmaapEvent(topic_subscribe_url, event):
    '''
    handle event
    :param event: an events
    :return:
    '''
    try:
        # validate
        if "APPC-LCM-READ" not in topic_subscribe_url:
            return
        if not event:
            return

        if event.get("rpc-name", None) != "restart":
            return

        vserver_name = event['body']['input']['action-identifiers']['vnf-id']
        logger.debug("restart the vserver: %s" % vserver_name)

        # search node in AAI
        aai_searchnode_url = ("/search/nodes-query?search-node-type=vserver&filter=vserver-name:EQUALS:%(vserver-name)s"
                        % {
                            "vserver-name": vserver_name
                        })

        # get cloud-region
        retcode, content, status_code = \
            restcall.req_to_aai(aai_searchnode_url, "GET")

        if retcode == 0 and content:
            content = json.JSONDecoder().decode(content)
            '''
            {"result-data":[
            {"resource-type":"vserver",
            "resource-link":"/aai/v13/cloud-infrastructure/cloud-regions/cloud-region/CloudOwner/RegionOne/tenants/tenant/0e148b76ee8c42f78d37013bf6b7b1ae/vservers/vserver/8e606aa7-39c8-4df7-b2f4-1f6785b9f682"
            }]}
            '''
            resultdata = content['result-data'][0]
            #resource_link = resultdata['resource-link'].replace("/aai/%s"%(settings.AAI_SCHEMA_VERSION), "")\
            #    if resultdata['resource-link'] else None

            resource_link = resultdata['resource-link'] \
                    if resultdata['resource-link'] else None

            if not resource_link:
                return
            logger.debug("resource-link: %s" % resource_link)

            # decode the resource link, extract cloud_owner, cloud_region_id, vserver_id
            m = re.search(r'^/aai/v[0-9.]/cloud-infrastructure/cloud-regions/cloud-region/([0-9a-zA-Z/._-]+)/([0-9a-zA-Z/._-]+)/tenants/tenant/([0-9a-zA-Z/._-]+)/vservers/vserver/([0-9a-zA-Z/._-]+)$', resource_link)
            if not m:
                logger.error("resource_link is not a valid vserver link:%s" % (resource_link))
                return
            else:
                cloud_owner = m.group(1)
                cloud_region_id = m.group(2)
                tenant_id = m.group(3)
                vserver_id = m.group(4)

            from common.msapi.helper import Helper as helper

            # get v2.0/token
            v2_token_resp_json = helper.MultiCloudIdentityHelper(settings.MULTICLOUD_API_V1_PREFIX,
                                                                 cloud_owner, cloud_region_id, "/v2.0/tokens")
            if not v2_token_resp_json:
                logger.error("authenticate fails:%s,%s" % (cloud_owner, regionid))
                return

            # stop vserver
            service_type = "compute"
            resource_uri = "/servers/%s" % (vserver_id)
            action = {"os-stop": {}}
            logger.info("stop vserver, URI:%s" % resource_uri)
            content = helper.MultiCloudServiceHelper(cloud_owner, cloud_region_id, v2_token_resp_json, service_type,
                                                     resource_uri, action, "POST")

            time.sleep(10)

            # start vserver
            service_type = "compute"
            resource_uri = "/servers/%s" % (vserver_id)
            action = {"os-start": {}}
            logger.info("stop vserver, URI:%s" % resource_uri)
            content = helper.MultiCloudServiceHelper(cloud_owner, cloud_region_id, v2_token_resp_json, service_type,
                                                     resource_uri, action, "POST")

        pass
    except Exception as e:
        logger.error("exception:%s" % str(e))

    pass